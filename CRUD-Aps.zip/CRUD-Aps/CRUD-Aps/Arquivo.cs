﻿namespace CRUD_Aps
{
    class Arquivo
    {
        public string LocalArquivo { get; set; }
        public string NomeArquivo { get; set; }
        public string ConteudoArq { get; set; }
        public string[] conteudo { get; set; }
        public string msg { get; set; }
        public string Status { get; set; }
    }
}
